To enable StarCluster bash-completion support for every 
shell you open, add the following line to your ~/.bashrc file:

source /path/to/starcluster/completion/starcluster-completion.sh
