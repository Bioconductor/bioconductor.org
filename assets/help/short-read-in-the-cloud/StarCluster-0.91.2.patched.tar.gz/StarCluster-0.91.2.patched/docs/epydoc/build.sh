#!/bin/bash
epydoc -v --config scepydoc.conf
